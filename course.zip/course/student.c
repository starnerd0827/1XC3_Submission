/**
 * @file student.c
 * @author TAs
 * @date 04/08/22
 * @brief File containing function definitions for all functions dealing with the Student type
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Takes in a student and a grade, and adds that grade to the array of the student's grades
 * 
 * @param student the student represented by the Student type
 * @param grade the grade that one wishes to add to the array of a student's grades
 * @return Nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //Uses calloc if this is the first grade in the array (to allocate the memory)
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //Otherwise uses realloc (to reallocate memory that has already been allocated)
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the average of the student provided
 * 
 * @param student The student (represented by the Student type) whose average is being calculated
 * @return double The average grade of the student
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  //Loop calculating the average of the student
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief Prints a student (represented by the Student type) incl. full name, student id, the list of their grades, and their average
 * 
 * @param student The student that needs to be printed
 * @return Nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  //Prints every grade contained within the student's list of grades
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Generates a random student (of type Student) and fills in their respective data using random numbers and lists.
 * 
 * @param grades The number of grades the student will have
 * @return Student* The random student with new random data
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  //Picks a random first and last name from the lists above
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Generates a random 10-digit student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Adds the correct number of random grades to the student's grade list.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}