/**
 * @file course.h
 * @author TAs
 * @brief Library containing the type definition of course, as well as initializing and linking related functions.
 * @date 2022-04-08
 * 
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
* @brief Course type stores a course with fields name, code, students, and total students.
*
*/
typedef struct _course 
{
  char name[100]; /**< The course name */
  char code[10]; /**< The course code*/
  Student *students; /**< An array containing the students enrolled in the course*/
  int total_students; /**< The total number of students enrolled in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


