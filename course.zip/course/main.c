/**
 * @file main.c
 * @author TAs
 * @brief Generates a course (of the type Course) filled with random students (of the type Student) and prints the contents.
 * @date 2022-04-08
 * 
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Generates a course and fills it with random students. Then prints the contents and certain statistics of the course. 
 *  
 */
int main()
{
  srand((unsigned) time(NULL));

  //Generates the course Basics of Mathematics
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Fills said course with random students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Finds and prints the student with the best average
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Calculates and prints the total number of passing students
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}