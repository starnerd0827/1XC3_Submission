/**
 * @file course.c
 * @author TAs
 * @brief File containing the function definitions that deal with the Course type
 * @date 2022-04-08
 * 
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Takes in a course and student. Adds the student to the course provided.
 * 
 * @param course The course (represented by a Course type) in which the student is being enrolled
 * @param student The student (represented by a Student type) that is being added to the course
 * @return Nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints a course incl. course name, course code, total number of students, and each student (and their data)
 * 
 * @param course The course that needs to be printed
 * @return Nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Goes through each student in the course, prints them and their associated data
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Compares the average of each student in a course, and returns the student with the highest average
 * 
 * @param course The course in which the top student is being found
 * @return Student* Returns the student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //Goes through and compares the averages of each student in the course. Replaces the max average if a student's is higher.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief Checks the average of each student in a course and returns a list of the students who are passing.
 * 
 * @param course The course that is being checked for passing students.
 * @param total_passing Points to an integer that will store the total number of passing students
 * @return Student* A list of students (represented by the Student type) who are passing the course (have an average > 50).
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Counts the total number of passing students in the course (needed individually for memory purposes)
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  //Adds each passing students to an array, and returns that array.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}