/**
 * @file student.h
 * @author TAs
 * @brief A library containing the definition of the Student type and related functions
 * @date 2022-04-08
 * 
 * 
 * 
 */

/**
* @brief Student type stores a student with fields first_name, last_name, id, grades, and num_grades.
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's student id */
  double *grades; /**< an array containing every grade that a student has*/
  int num_grades; /**< the number of grades that a student has*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
